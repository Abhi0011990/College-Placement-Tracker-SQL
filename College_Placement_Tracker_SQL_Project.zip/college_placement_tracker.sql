-- College Placement Tracker Project (SQL, MySQL | 2025)

-- Create Database
CREATE DATABASE CollegePlacementTracker;
USE CollegePlacementTracker;

-- Table: students
CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    branch VARCHAR(50),
    cgpa DECIMAL(3,2),
    email VARCHAR(100),
    phone VARCHAR(15)
);

-- Table: companies
CREATE TABLE companies (
    company_id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(100),
    eligibility_cgpa DECIMAL(3,2),
    job_role VARCHAR(100),
    location VARCHAR(100)
);

-- Table: applications
CREATE TABLE applications (
    application_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    company_id INT,
    application_date DATE,
    status ENUM('Applied', 'Selected', 'Rejected'),
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (company_id) REFERENCES companies(company_id)
);

-- Sample Data Insertion
INSERT INTO students (name, branch, cgpa, email, phone) VALUES
('Abhishek Kumar', 'CSE', 8.7, 'abhishek@college.edu', '9876543210'),
('Riya Sharma', 'ECE', 7.9, 'riya@college.edu', '8765432109'),
('Arjun Mehta', 'CSE', 9.1, 'arjun@college.edu', '7654321098');

INSERT INTO companies (company_name, eligibility_cgpa, job_role, location) VALUES
('TCS', 7.0, 'Software Engineer', 'Bangalore'),
('Infosys', 7.5, 'System Engineer', 'Pune'),
('Google', 8.5, 'SDE', 'Hyderabad');

INSERT INTO applications (student_id, company_id, application_date, status) VALUES
(1, 1, '2025-10-10', 'Selected'),
(2, 2, '2025-10-12', 'Applied'),
(3, 3, '2025-10-15', 'Applied');

-- Example Queries

-- 1. Eligible Students per Company
SELECT s.name, s.cgpa, c.company_name
FROM students s
JOIN companies c
ON s.cgpa >= c.eligibility_cgpa;

-- 2. Application Count per Company
SELECT c.company_name, COUNT(a.application_id) AS total_applications
FROM companies c
LEFT JOIN applications a
ON c.company_id = a.company_id
GROUP BY c.company_name;

-- 3. Selected Students with Company
SELECT s.name, c.company_name, a.status
FROM applications a
JOIN students s ON a.student_id = s.student_id
JOIN companies c ON a.company_id = c.company_id
WHERE a.status = 'Selected';

-- 4. Create Indexes
CREATE INDEX idx_cgpa ON students(cgpa);
CREATE INDEX idx_company_id ON applications(company_id);
